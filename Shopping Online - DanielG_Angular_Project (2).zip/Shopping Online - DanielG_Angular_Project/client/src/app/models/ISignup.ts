export interface ISignup {
        idNumber: string,
        email: string,
        password: string,
        confirmPassword: string,
        firstName: string,
        lastName: string,
        streetName: string,
        cityName: string, 
}