export interface ILogin{
idNumber: string,
password: string
}