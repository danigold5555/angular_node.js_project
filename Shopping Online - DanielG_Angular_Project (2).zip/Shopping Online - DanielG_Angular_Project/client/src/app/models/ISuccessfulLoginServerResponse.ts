export interface ISuccessfulLoginServerResponse {
    successfulLoginResponse: string;
}
