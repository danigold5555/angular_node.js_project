export interface IOrder{
    customerId: number;
    cartId: number;
    finalPrice: number;
    cityName: string;
    streetName: string;
    shipmentDate: string;
    orderDate: string;
    creditCard: string;
    }