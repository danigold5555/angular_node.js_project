export interface IProductsCount{
productsQuantity: number;
}