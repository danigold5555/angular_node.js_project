export interface IDecodedToken{
iat: number;
idNumber: number;
password: string;
}